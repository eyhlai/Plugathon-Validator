# Plugathon validation IG - v0.1.0

* [**Table of Contents**](toc.md)
* **Plugathon validation IG**

## Plugathon validation IG

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/PlugathonValidationIG/ImplementationGuide/example.org.fhir.plugathon.validation | *Version*:0.1.0 |
| Draft as of 2025-10-30 | *Computable Name*:PlugathonValidationIG |

See the [QA results](qa.md).

